package com.example.wrg.ordertest;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class PaymentActivity extends AppCompatActivity {


    @SuppressWarnings("ResourceType")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        String[] countlist = getResources().getStringArray(R.array.count);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,countlist);
        Spinner spi = (Spinner)findViewById(R.id.countspinner);
        spi.setAdapter(adapter);
        spi.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                print(view,position);

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }


        });
        ///스피너 종료

        //check box data 가져오기

        Intent box = getIntent();

        int data = box.getExtras().getInt("check"); // data값이 넘어옴 정상 작동
        TextView price = (TextView)findViewById(R.id.Price);
        int[] Iprice = getResources().getIntArray(R.array.PriceList); //정상 작동
        int temp = Iprice[data]; // 여기도 문제 x
        String TextPrice = Integer.toString(temp); // 문제 x
        price.setText(TextPrice);
        //price change success

        ImageView payView = (ImageView)findViewById(R.id.PaymentImageView);

        for(int i=0; i<5; i++) {

            if(data == i){
                payView.setImageResource(R.drawable.gametitle_01+i);
                break;
            }

        }
        //ImageView의 Image change Success
    }
    public void print(View v, int position){
        Spinner sp = (Spinner)findViewById(R.id.countspinner);
        TextView price=(TextView)findViewById(R.id.Price);
        TextView Total=(TextView)findViewById(R.id.TotalPrice);
        //spinner 준비
        Intent box = getIntent();
        int data = box.getExtras().getInt("check"); // data값이 넘어옴 정상 작동
        int[] Iprice = getResources().getIntArray(R.array.PriceList); //정상 작동
        int temp = Iprice[data]; //여기도 문제 x
        //price값 받아오기

        int temp1 =0;
        int temptotal =0;
        String res="";
        if(sp.getSelectedItemPosition()>=0){

            res=(String)sp.getAdapter().getItem(sp.getSelectedItemPosition());

        }
        if(res !=""){

            temp1 = Integer.parseInt(res);
            temptotal = temp1 * temp;

            Total.setText(Integer.toString(temptotal));
        }
    }


    public void OnButtonPay(View v) {
        finish();

        Intent SbIntent = new Intent(getApplicationContext(),PayActivity.class);

        startActivity(SbIntent);
    }

    public void OnButtonBack(View v){
        Toast.makeText(getApplicationContext(),"주문으로 돌아가라",Toast.LENGTH_LONG).show();
        finish();
    }


}
