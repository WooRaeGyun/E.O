package com.example.wrg.ordertest;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

public class PwdchangeActivity extends AppCompatActivity {

    EditText changepwd;
    String change;
    String data;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pwdchange);

        Intent UserId = getIntent();
        data = UserId.getExtras().getString("UserID"); // data값이 넘어옴 정상 작동


    }

    public void OnButtonOk(View v) {

        EditText nowpwd =(EditText)findViewById(R.id.NowPwd); //현재 Pwd
        changepwd = (EditText)findViewById(R.id.ChangePwd); //처음 입력한 pwd
        EditText changecheck = (EditText)findViewById(R.id.ChangePwdCheck); //두번째 입력한 pwd

        String now = nowpwd.getText().toString(); //현재 pwd ->String
        change = changepwd.getText().toString(); //처음 change ->String
        String check =changecheck.getText().toString(); //두번째 change ->String

        if(now.length()==0){
            Toast.makeText(getApplicationContext(),"now Pwd is Blank",Toast.LENGTH_LONG).show();
        }

        else if(change.length() ==0){
            Toast.makeText(getApplicationContext(),"Change Pwd is Blank ",Toast.LENGTH_LONG).show();
        }

        else if(!change.equals(check)){
            Toast.makeText(getApplicationContext(),"Check change Pwd",Toast.LENGTH_LONG).show();
        }


        else if (change.equals(check)) {
            insertToDatabase(data,change);
            //Toast.makeText(getApplicationContext(),"Pwd Change Success",Toast.LENGTH_LONG).show();
            finish();
            Intent HomeIntent = new Intent(getApplicationContext(), HomeActivity.class);
            startActivity(HomeIntent);
        }
    }

    private void insertToDatabase(String name, String address){

        class InsertData extends AsyncTask<String, Void, String> {   //AsyncTask: 백그라운드 스레드에서 실행되는 비동기 클래스

//            ProgressDialog loading;    //진행상황을 알려줄때 쓰는 클레스

            @Override
            protected void onPreExecute() {  //doInBackground 메소드가 실행되기 전에 실행되는 메소드
                super.onPreExecute();
//                loading = ProgressDialog.show(MainActivity.this, "Please Wait", null, true, true);
            }

            @Override
            protected void onPostExecute(String s) {  //doInBackground 메소드 후에 실행되는 메소드, 백그라운드 메소드의 반환값을 인자로 받아 그 결과를 화면에 반영
                super.onPostExecute(s);
//                loading.dismiss();
                Toast.makeText(getApplicationContext(),s,Toast.LENGTH_LONG).show();  //성공여부 알림메시지
            }

            @Override
            protected String doInBackground(String... params) {  //처리하고 싶은 내용을 작성

                try{
                    String id = (String)params[0];
                    String pwd = (String)params[1];

                    String link="http://14.63.225.187/Pwdchange.php";  //실행할 php페이지
                    String data  = URLEncoder.encode("uid", "UTF-8") + "=" + URLEncoder.encode(id, "UTF-8");  //보낼 데이터
                    data += "&" + URLEncoder.encode("pwd", "UTF-8") + "=" + URLEncoder.encode(pwd, "UTF-8");

                    URL url = new URL(link);  //페이지에 연결
                    URLConnection conn = url.openConnection();

                    conn.setDoOutput(true);  //전송허용
                    OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());

                    wr.write(data);
                    wr.flush();

                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                    StringBuilder sb = new StringBuilder();
                    String line = null;

                    // Read Server Response
                    while((line = reader.readLine()) != null)
                    {
                        sb.append(line);
                        break;
                    }
                    return sb.toString();
                }
                catch(Exception e){
                    return new String("Exception: " + e.getMessage());
                }

            }
        }

        InsertData task = new InsertData();  //쓰레드 생성
        task.execute(name,address);  //쓰레드 시작
    }


}
