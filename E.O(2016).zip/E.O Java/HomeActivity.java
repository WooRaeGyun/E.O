package com.example.wrg.ordertest;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ViewFlipper;


public class HomeActivity extends AppCompatActivity {

    ViewFlipper fipper;
    String data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        fipper =(ViewFlipper)findViewById(R.id.HomeFlipper);

        Animation showln = AnimationUtils.loadAnimation(this,android.R.anim.slide_in_left);
        //등장시 애니메이션 설정
        fipper.setInAnimation(showln);
        //왼쪽으로 가며 없어짐
        fipper.setOutAnimation(this,android.R.anim.slide_out_right);
        //넘겨지는 시간 설정
        fipper.setFlipInterval(2000);
        //슬라이드 자동 시작
        fipper.startFlipping();


    }

    ///action bar setting
    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_test,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){

        Intent SettingIntent = new Intent(getApplicationContext(),SettingActivity.class);
        startActivity(SettingIntent);
        return true;
    }

    public void OnButtonOrder(View v){
        finish();
        Intent Orderintent = new Intent(getApplicationContext(),OrderActivity.class);
        startActivity(Orderintent);
    }

    public void OnButtonMypage(View v){

        Intent UserId = getIntent();
        data = UserId.getExtras().getString("UserID"); // data값이 넘어옴 정상 작동
        finish();
        Intent MypageIntent = new Intent(getApplicationContext(),MypageActivity.class);
        MypageIntent.putExtra("UserID",data);
        startActivity(MypageIntent);
    }

    public void OnButtonOrderList(View v) {
        Intent UserId = getIntent();
        data = UserId.getExtras().getString("UserID"); // data값이 넘어옴 정상 작동
        finish();
        Intent OrderListIntent = new Intent(getApplicationContext(),OrderlistActivity.class);
        OrderListIntent.putExtra("UserID",data);
        startActivity(OrderListIntent);
    }

    public void OnButtonLogin(View v){
        finish();
        Intent LoginIntent = new Intent(getApplicationContext(),LoginActivity.class);
        startActivity(LoginIntent);
    }
}
