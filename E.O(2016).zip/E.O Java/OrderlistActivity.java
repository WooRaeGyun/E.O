package com.example.wrg.ordertest;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

public class OrderlistActivity extends AppCompatActivity {

    phpDown task;
    ListView list;
    ArrayList<String> orderList;
    String data;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_orderlist);

        Intent UserId = getIntent();
        data = UserId.getExtras().getString("UserID"); // data값이 넘어옴 정상 작동


        task = new phpDown();
        task.execute("http://14.63.225.187/OrderList_Json.php");
        //data원본
        orderList = new ArrayList<String>();


        /*orderList.add("자몽에이드");
        orderList.add("바닐라 라떼");
        orderList.add("아메리카노");
        orderList.add("카페 모카");

        //어댑터 준비
        ArrayAdapter<String> Adapter;
        Adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,orderList);
*/
        //어댑터 연결
        list = (ListView) findViewById(R.id.OrderList);
/*      Adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,orderList);
        list.setAdapter(Adapter);

        //리스트뷰 속성
        //항목 선택
        list.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
        //항목사이의 구분선 지정
        list.setDivider(new ColorDrawable(Color.BLUE));
        //구분선의 높이
        list.setDividerHeight(2);
*/
        /////////리스트뷰 끝

        //checkBox data 받기


    }


    public void OnButtonHome(View v) {

        finish();

        Intent HomeIntent = new Intent(getApplicationContext(), HomeActivity.class);

        startActivity(HomeIntent);
    }
    private class phpDown extends AsyncTask<String, Integer, String> {


        @Override
        protected String doInBackground(String... urls) {
            StringBuilder jsonHtml = new StringBuilder();
            try {
                // 연결 url 설정
                URL url = new URL(urls[0]);

                // 커넥션 객체 생성
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();


                // 연결되었으면.
                if (conn != null) {
                    conn.setConnectTimeout(10000);
                    conn.setUseCaches(false);

                    //추가 내용

                    String date  = URLEncoder.encode("user", "UTF-8") + "=" + URLEncoder.encode(data, "UTF-8");
                    OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
                    wr.write(date);
                    wr.flush();

                    // 연결되었음 코드가 리턴되면.
                    if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                        for (; ; ) {
                            // 웹상에 보여지는 텍스트를 라인단위로 읽어 저장.
                            String line = br.readLine();
                            if (line == null) break;
                            // 저장된 텍스트 라인을 jsonHtml에 붙여넣음
                            jsonHtml.append(line + "\n");
                        }
                        br.close();
                    }
                    conn.disconnect();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return jsonHtml.toString();

        }

        protected void onPostExecute(String str) {

            try{
                //PHP data를 Json obj로 변환
                JSONObject Jobject = new JSONObject(str);
                JSONArray results = Jobject.getJSONArray("results");
                JSONObject temp = new JSONObject();
                List<String> listContents = new ArrayList<String>(results.length());
                ArrayAdapter<String> Adapter;

                for(int i=0; i<results.length(); i++){

                    temp = results.getJSONObject(i);

                    listContents.add("이름 :" + temp.getString("Order_Name") +"\t\t\t\t\t\t\t\t\t\t\t\t                             "+"수량 : " +temp.getInt("Order_count"));
                }
                Adapter = new ArrayAdapter<String>( OrderlistActivity.this,android.R.layout.simple_list_item_1,listContents);
                list.setAdapter(Adapter);

                list.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
                //항목사이의 구분선 지정
                list.setDivider(new ColorDrawable(Color.BLUE));
                //구분선의 높이
                list.setDividerHeight(2);
                // for(int j =0; j<temp.length(); j++){




                //}
            }catch (JSONException e){
                e.printStackTrace();

            }


        }


    }



}
