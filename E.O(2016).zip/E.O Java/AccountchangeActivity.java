package com.example.wrg.ordertest;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

public class AccountchangeActivity extends AppCompatActivity {

    String data;
    String bankname;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_accountchange);

        Intent UserId = getIntent();
        data = UserId.getExtras().getString("UserID"); // data값이 넘어옴 정상 작동


        String[] BankL = getResources().getStringArray(R.array.BankList);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,BankL);
        Spinner spi = (Spinner)findViewById(R.id.Bankspinner);
        spi.setAdapter(adapter);
        spi.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                print(view,position);

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }


        });
    }
    public void print(View v, int position){
        Spinner sp = (Spinner)findViewById(R.id.Bankspinner);
        TextView tx=(TextView)findViewById(R.id.BankText);
        String res="";
        if(sp.getSelectedItemPosition()>0){
            res=(String)sp.getAdapter().getItem(sp.getSelectedItemPosition());
        }
        if(res !=""){
            bankname = res;
        }
    }

    public void OnButtonOk(View v) {

        EditText Account1 =(EditText)findViewById(R.id.us_Account_1); //계좌 첫줄
        EditText Account2 = (EditText)findViewById(R.id.Account2); //계좌2째줄
        EditText AccountPwd = (EditText)findViewById(R.id.AccountPwdT); //계좌 pwd

        String AC1 = Account1.getText().toString(); //첫 acc ->String
        String AC2 = Account2.getText().toString(); //둘 acc ->String
        String AP =AccountPwd.getText().toString(); //pwd check ->String

        if(AC1.length()<8 ){
            Toast.makeText(getApplicationContext(),"Account1 Check",Toast.LENGTH_LONG).show();
        }
        else if(AC2.length()<7){
            Toast.makeText(getApplicationContext(),"Account2 Check",Toast.LENGTH_LONG).show();
        }
        else if(AP.length()<4){
            Toast.makeText(getApplicationContext(),"Account Pwd Check",Toast.LENGTH_LONG).show();
        }
        if(AC1.length() == 8) {
            if(AC2.length() == 7) {
                if(AP.length() == 4) {
                    finish();
                    String acc = AC1 +AC2;
                    insertToDatabase(data,acc,AP,bankname);
                    Intent HomeIntent = new Intent(getApplicationContext(), HomeActivity.class);
                    startActivity(HomeIntent);
                }
            }
        }
    }
    private void insertToDatabase(String name, String address, String pwd, String bank){

        class InsertData extends AsyncTask<String, Void, String> {   //AsyncTask: 백그라운드 스레드에서 실행되는 비동기 클래스

//            ProgressDialog loading;    //진행상황을 알려줄때 쓰는 클레스

            @Override
            protected void onPreExecute() {  //doInBackground 메소드가 실행되기 전에 실행되는 메소드
                super.onPreExecute();
//                loading = ProgressDialog.show(MainActivity.this, "Please Wait", null, true, true);
            }

            @Override
            protected void onPostExecute(String s) {  //doInBackground 메소드 후에 실행되는 메소드, 백그라운드 메소드의 반환값을 인자로 받아 그 결과를 화면에 반영
                super.onPostExecute(s);
//                loading.dismiss();
                Toast.makeText(getApplicationContext(),s,Toast.LENGTH_LONG).show();  //성공여부 알림메시지
            }

            @Override
            protected String doInBackground(String... params) {  //처리하고 싶은 내용을 작성

                try{
                    String id = (String)params[0];
                    String acc = (String)params[1];
                    String acpwd =(String)params[2];
                    String bankn =(String)params[3];

                    String link="http://14.63.225.187/AccountChange.php";  //실행할 php페이지
                    String data  = URLEncoder.encode("uid", "UTF-8") + "=" + URLEncoder.encode(id, "UTF-8");  //보낼 데이터
                    data += "&" + URLEncoder.encode("acc", "UTF-8") + "=" + URLEncoder.encode(acc, "UTF-8");
                    data += "&" + URLEncoder.encode("acpwd", "UTF-8") + "=" + URLEncoder.encode(acpwd, "UTF-8");
                    data += "&" + URLEncoder.encode("bankn", "UTF-8") + "=" + URLEncoder.encode(bankn, "UTF-8");

                    URL url = new URL(link);  //페이지에 연결
                    URLConnection conn = url.openConnection();

                    conn.setDoOutput(true);  //전송허용
                    OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());

                    wr.write(data);
                    wr.flush();

                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                    StringBuilder sb = new StringBuilder();
                    String line = null;

                    // Read Server Response
                    while((line = reader.readLine()) != null)
                    {
                        sb.append(line);
                        break;
                    }
                    return sb.toString();
                }
                catch(Exception e){
                    return new String("Exception: " + e.getMessage());
                }

            }
        }

        InsertData task = new InsertData();  //쓰레드 생성
        task.execute(name,address,pwd,bank);  //쓰레드 시작
    }



}
