package com.example.wrg.ordertest;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class SettingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);

        Button Home = (Button) findViewById(R.id.SettingHomeButton);

        Home.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                RadioGroup event = (RadioGroup) findViewById(R.id.EventG);
                RadioGroup push = (RadioGroup) findViewById(R.id.PhushG);
                RadioGroup Login = (RadioGroup) findViewById(R.id.AutoLginG);

                int eventid = event.getCheckedRadioButtonId();
                int pushid = push.getCheckedRadioButtonId();
                int loginid = Login.getCheckedRadioButtonId();

                RadioButton evid = (RadioButton) findViewById(eventid);
                RadioButton puid = (RadioButton) findViewById(pushid);
                RadioButton loid = (RadioButton) findViewById(loginid);

                Toast.makeText(getApplicationContext(), "vent"+evid.getText() + ", Push" + puid.getText() + ",Auto" + loid.getText(), Toast.LENGTH_LONG).show();

                finish();

               Intent HomeIntent = new Intent(getApplicationContext(), HomeActivity.class);

                startActivity(HomeIntent);
            }


        });
    }
}



