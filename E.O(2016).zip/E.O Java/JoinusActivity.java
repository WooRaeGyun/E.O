package com.example.wrg.ordertest;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;


public class JoinusActivity extends AppCompatActivity {

    EditText uid;
    EditText pwd;
    EditText num;
    EditText acc2;
    EditText acc1;
    String ID;
    String PWD;
    String bank;
    /////conn
    phpDown take;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_joinus);

        take = new phpDown();


        uid = (EditText)findViewById(R.id.us_id);
        pwd = (EditText)findViewById(R.id.us_pwd);
        num =(EditText)findViewById(R.id.us_phon);
        acc1 = (EditText)findViewById(R.id.us_Account_1);
        acc2 =(EditText)findViewById(R.id.us_Account_2);



//        task = new phpInsert();


        String[] BankL = getResources().getStringArray(R.array.BankList);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,BankL);
        Spinner spi = (Spinner)findViewById(R.id.Bankspinner);
        spi.setAdapter(adapter);
        spi.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                print(view,position);

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }


        });
    }
    public void print(View v, int position){
        Spinner sp = (Spinner)findViewById(R.id.Bankspinner);
        TextView tx=(TextView)findViewById(R.id.BankText);
        String res="";
        if(sp.getSelectedItemPosition()>0){
            res=(String)sp.getAdapter().getItem(sp.getSelectedItemPosition());
        }
        if(res !=""){
            bank = res;
        }
    }

    public void OnButtonOverLap(View v){
        ID = uid.getText().toString();
        take.execute("http://14.63.225.187/UserInfo_Json.php");

    }


    public void OnButtonJoin(View v){
        finish();
        ID = uid.getText().toString();
        PWD = pwd.getText().toString();
        String hp = num.getText().toString();
        String ACC = acc1.getText().toString()+acc2.getText().toString();
//        task.execute("http://14.63.225.187/test.php"+ ID);

        insertToDatabase(ID,PWD,hp,ACC,bank);
        Intent Home = new Intent(getApplicationContext(),HomeActivity.class);
        startActivity(Home);
    }

    private void insertToDatabase(String name, String address,String HP, String stracc,String BANK){

        class InsertData extends AsyncTask<String, Void, String>{   //AsyncTask: 백그라운드 스레드에서 실행되는 비동기 클래스

//            ProgressDialog loading;    //진행상황을 알려줄때 쓰는 클레스

            @Override
            protected void onPreExecute() {  //doInBackground 메소드가 실행되기 전에 실행되는 메소드
                super.onPreExecute();
//                loading = ProgressDialog.show(MainActivity.this, "Please Wait", null, true, true);
            }

            @Override
            protected void onPostExecute(String s) {  //doInBackground 메소드 후에 실행되는 메소드, 백그라운드 메소드의 반환값을 인자로 받아 그 결과를 화면에 반영
                super.onPostExecute(s);
//                loading.dismiss();
                Toast.makeText(getApplicationContext(),s,Toast.LENGTH_LONG).show();  //성공여부 알림메시지
            }

            @Override
            protected String doInBackground(String... params) {  //처리하고 싶은 내용을 작성

                try{
                    String id = (String)params[0];
                    String pwd = (String)params[1];
                    String ph =(String)params[2];
                    String strAcc = (String)params[3];
                    String strbank = (String)params[4];

                    String link="http://14.63.225.187/Joinus.php";  //실행할 php페이지
                    String data  = URLEncoder.encode("id", "UTF-8") + "=" + URLEncoder.encode(id, "UTF-8");  //보낼 데이터
                    data += "&" + URLEncoder.encode("pwd", "UTF-8") + "=" + URLEncoder.encode(pwd, "UTF-8");
                    data += "&" + URLEncoder.encode("hp", "UTF-8") + "=" + URLEncoder.encode(ph, "UTF-8");
                    data += "&" + URLEncoder.encode("acc", "UTF-8") + "=" + URLEncoder.encode(strAcc, "UTF-8");
                    data += "&" + URLEncoder.encode("bank", "UTF-8") + "=" + URLEncoder.encode(strbank, "UTF-8");

                    URL url = new URL(link);  //페이지에 연결
                    URLConnection conn = url.openConnection();

                    conn.setDoOutput(true);  //전송허용
                    OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());

                    wr.write(data);
                    wr.flush();

                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                    StringBuilder sb = new StringBuilder();
                    String line = null;

                    // Read Server Response
                    while((line = reader.readLine()) != null)
                    {
                        sb.append(line);
                        break;
                    }
                    return sb.toString();
                }
                catch(Exception e){
                    return new String("Exception: " + e.getMessage());
                }

            }
        }

        InsertData task = new InsertData();  //쓰레드 생성
        task.execute(name,address,HP,stracc,BANK);  //쓰레드 시작
    }
    //php에서 data를 가져옴.
    private class phpDown extends AsyncTask<String, Integer, String> {


        @Override
        protected String doInBackground(String... urls) {
            StringBuilder jsonHtml = new StringBuilder();
            try {
                // 연결 url 설정
                URL url = new URL(urls[0]);
                // 커넥션 객체 생성
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                // 연결되었으면.
                if (conn != null) {
                    conn.setConnectTimeout(10000);
                    conn.setUseCaches(false);
                    // 연결되었음 코드가 리턴되면.
                    if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                        for (; ; ) {
                            // 웹상에 보여지는 텍스트를 라인단위로 읽어 저장.
                            String line = br.readLine();
                            if (line == null) break;
                            // 저장된 텍스트 라인을 jsonHtml에 붙여넣음
                            jsonHtml.append(line + "\n");
                        }
                        br.close();
                    }
                    conn.disconnect();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return jsonHtml.toString();

        }

        protected void onPostExecute(String str) {

            try{
                //PHP data를 Json obj로 변환
                JSONObject Jobject = new JSONObject(str);
                JSONArray results = Jobject.getJSONArray("results");
                JSONObject temp = new JSONObject();




                for(int i=0; i<results.length(); i++){
                    temp = results.getJSONObject(i);
                    if(temp.getString("User_Id").equals(ID)){
                     Toast.makeText(getApplicationContext(),"ID 중복",Toast.LENGTH_LONG).show();
                    }
                    else{
                        Toast.makeText(getApplicationContext(),"ID No 중복",Toast.LENGTH_LONG).show();
                    }
                }
                // for(int j =0; j<temp.length(); j++){





                //}
            }catch (JSONException e){
                e.printStackTrace();
            }

        }


    }


}
