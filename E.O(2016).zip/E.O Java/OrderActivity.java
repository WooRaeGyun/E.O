package com.example.wrg.ordertest;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.Toast;


public class OrderActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order);
    }
    public void OnButtonBack(View v){
        Toast.makeText(getApplicationContext(),"홈으로 돌아가라",Toast.LENGTH_LONG).show();
        finish();
    }

    public void OnButtonSelect(View v) {
        finish();

        CheckBox OrderCheck1 = (CheckBox)findViewById(R.id.OrderCheck1);
        CheckBox OrderCheck2 = (CheckBox)findViewById(R.id.OrderCheck2);

        Intent checkdata = new Intent(getApplicationContext(),PaymentActivity.class);
        if(OrderCheck1.isChecked() == true){ checkdata.putExtra("check",0); }
        if(OrderCheck2.isChecked() == true){ checkdata.putExtra("check",1); }

        //Intent PaymentIntent = new Intent(getApplicationContext(),PaymentActivity.class);
        startActivity(checkdata);
        //startActivity(PaymentIntent);

    }
}
