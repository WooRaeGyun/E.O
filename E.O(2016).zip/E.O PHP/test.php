<?php

  $hostname = "14.63.225.187";
  $dbid = "root";
  $dbpw = "Genius";
  $dbname = "EO";

  $db = mysql_connect("localhost", $dbid, $dbpw) or die("개빡");
  mysql_select_db($dbname,$db);

  $query= "select * from UserInfo";
  // 쿼리를 실행하고 그 결과값을 $result변수에 넣는다.
  $result = mysql_query($query, $db);
  $total_record = mysql_num_rows($result);
 
  $result_array = array();
 
  for ( $i = 0; $i < $total_record; $i++ ) {
  // 한행씩 읽기 위해 offset을 준다.
    
    mysql_data_seek($result, $i);
  
  // 결과값을 배열로 바꾼다.
    $row = mysql_fetch_array($result);
  // 결과값들을 JSON형식으로 넣기 위해 연관배열로 넣는다.
    $row_array = array(
      "User_No" => $row['User_No'],
      "User_Id" => $row['User_Id'],
      "User_Pwd" => $row['User_Pwd'],
      "User_Name" => $row['User_Name'],
      "User_HP" => $row['User_HP'],
      "User_Bank" => $row['User_Bank'],
      "User_Anum" => $row['User_Anum'],
      "User_Count" => $row['User_Count'],
      );
  // 한 행을 results에 넣을 배열의 끝에 추가한다.
    array_push($result_array,$row_array);
  }
 

// 위에서 얻은 결과를 다시 JSON형식으로 넣는다.
  $arr = array(
    "status" => "OK",
    "num_result" => "$total_record",
    "results" => "$result_array"
    );
 
// 만든건 그냥 배열이므로 JSON형식으로 인코딩을 한다.
  $json_array = json_encode($arr);
 
// 인코딩한 JSON배열을 출력한다.
  echo $row_array;
  echo "<BR>";
  echo $arr;
  echo "<BR>";
  echo $json_array;
?>