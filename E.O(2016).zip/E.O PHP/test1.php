<?php

  $hostname = "14.63.225.187";
  $dbid = "root";
  $dbpw = "Genius";
  $dbname = "EO";

  $db = mysql_connect("localhost", $dbid, $dbpw) or die("개빡");
  mysql_select_db($dbname,$db);

  $query = "Select * From UserInfo";

  $result = mysql_query($db,$query);

  $result_arry = array();

  $total_record = mysql_num_rows($result);

  for($i=0; $i<total_record; $i++){
  	
    $row_array = array(
      "User_No" => "$row[User_No]",
      "User_Id" => "$row[User_Id]",
      "User_Pwd" => "$row[User_Pwd]",
      "User_Name" => "$row[User_Name]",
      "User_HP" => "$row[User_HP]",
      "User_Bank" => "$row[User_Bank]",
      "User_Anum" => "$row[User_Anum]",
      "User_Count" => "$row[User_Count]",

      );

      array_push($result_arry, $row_array);
  }

  $json_arry = json_encode($row_array);

  echo "$row_array";

  echo "<BR>";

  echo "$json_arry";
  ?>