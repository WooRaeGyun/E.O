<?php
	//session_start();

	$hostname = "14.63.225.187";
	$dbid = "root";
	$dbpw = "Genius";
	$dbname = "EO";

	$db = mysql_connect("localhost", $dbid, $dbpw) or die("개빡");
	mysql_select_db($dbname,$db);

//	if ($db->connect_error) {
	//	die('DB Connect fail..');
//	}
//	else{
	//echo " DB Connect Success!! ";
	
	// 쿼리문 생성
   $sql = "select * from UserInfo";
   // 쿼리 실행 결과를 $result에 저장
   $result = mysql_query($sql, $db);

   if(!$result){
      printf("Error:%s\n", mysql_error($db));
      exit();
   }
   // 반환된 전체 레코드 수 저장.
   $total_record = mysql_num_rows($result);

   
   // JSONArray 형식으로 만들기 위해서...
   echo "{\"status\":\"OK\",\"num_results\":\"$total_record\",\"results\":[";
 
   // 반환된 각 레코드별로 JSONArray 형식으로 만들기.
   for ($i=0; $i < $total_record; $i++)                    
   {
      // 가져올 레코드로 위치(포인터) 이동  
      //mysqli_data_seek($result, $i);       
        
      $row = mysql_fetch_array($result);


  echo "{\"User_No\":\"$row[User_No]\",
   			\"User_Id\":\"$row[User_Id]\",
   			\"User_Pwd\":\"$row[User_Pwd]\",
   			\"User_Name\":\"$row[User_Name]\",
   			\"User_Bank\":\"$row[User_Bank]\",
   			\"User_Annum\":\"$row[User_Annum]\",
   			\"User_Count\":\"$row[User_Count]\"}";
 
   // 마지막 레코드 이전엔 ,를 붙인다. 그래야 데이터 구분이 되니깐.  
   if($i<$total_record-1){
      echo ",";
      echo "<BR>";
   }
    
   }
   // JSONArray의 마지막 닫기
   echo "]}";
//}

	
?>